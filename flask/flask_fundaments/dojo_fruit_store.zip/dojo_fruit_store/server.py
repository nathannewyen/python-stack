from flask import Flask, render_template, request
app = Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html")


@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if request.method == "POST":
        form = request.form
        charging = form["strawberry"], form["raspberry"], form["apple"], form["blackberry"]
        count = 0
        for i in range(0, len(charging)):
            count = count + int(charging[i])
        print("Charging " + form["first_name"] + " " +
              form["last_name"] + " for " + str(count) + " fruits")

    elif request.form == "GET":
        form = request.args

    return render_template(
        "checkout.html",
        strawberry=form["strawberry"],
        raspberry=form["raspberry"],
        apple=form["apple"],
        blackberry=form["blackberry"],
        first_name=form["first_name"],
        last_name=form["last_name"],
        student_id=form["student_id"],
        count=count
    )


@app.route('/fruits')
def fruits():
    return render_template("fruits.html")


if __name__ == "__main__":
    app.run(debug=True)
