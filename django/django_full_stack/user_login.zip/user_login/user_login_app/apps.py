from django.apps import AppConfig


class UserLoginAppConfig(AppConfig):
    name = 'user_login_app'
