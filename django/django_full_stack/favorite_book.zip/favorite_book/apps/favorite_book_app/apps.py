from django.apps import AppConfig


class FavoriteBookAppConfig(AppConfig):
    name = 'favorite_book_app'
