from django.shortcuts import render, redirect

from .models import Show

# Create your views here.


def index(request):
    return render(request, 'index.html')


def all_show_info(request):
    all_shows = Show.objects.all()
    context = {
        "all_shows": all_shows,
    }

    return render(request, 'all_show_info.html', context)


def single_show_info(request, id):
    show = Show.objects.get(id=id)
    context = {
        'id': id,
        'show': show
    }
    return render(request, 'single_show_info.html', context)


def new_show(request):
    return render(request, 'new_show.html')


def create(request):
    if len(str(request.POST["title"])) < 2:
        print("Needs more the 2 characters to submit")
    else:
        this_show = Show.objects.create(
            title=request.POST["title"], network=request.POST["network"],
            release_date=request.POST["release_date"], description=request.POST["description"])

    return redirect(f"/shows/{this_show.id}")


def show_edit(request, id):
    show = Show.objects.get(id=id)
    context = {
        'show': show,
        'id': id
    }
    return render(request, 'edit_show.html', context)


def update(request, id):
    show = Show.objects.get(id=id)
    if request.method == 'POST':
        show.title = request.POST["title"]
        show.network = request.POST["network"]
        show.release_date = request.POST["release_date"]
        show.description = request.POST["description"]
        show.save()
    else:
        pass
    return redirect(f"/shows/{show.id}")


def delete(request, id):
    show = Show.objects.get(id=id)
    if request.method == "GET":
        show.delete()
    return redirect("/shows")
