from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('shows/', views.all_show_info),
    path('shows/<id>', views.single_show_info),
    path('shows/new/', views.new_show),
    path('shows/<id>/edit', views.show_edit),
    path('shows/create/', views.create),
    path('shows/<id>/update', views.update),
    path('shows/<id>/destroy', views.delete)
]
