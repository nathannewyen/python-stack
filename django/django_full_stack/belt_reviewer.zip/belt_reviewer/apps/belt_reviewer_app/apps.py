from django.apps import AppConfig


class BeltReviewerAppConfig(AppConfig):
    name = 'belt_reviewer_app'
