from django.apps import AppConfig


class UserDashboardAppConfig(AppConfig):
    name = 'user_dashboard_app'
