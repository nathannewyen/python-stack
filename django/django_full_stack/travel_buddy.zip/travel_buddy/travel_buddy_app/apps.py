from django.apps import AppConfig


class TravelBuddyAppConfig(AppConfig):
    name = 'travel_buddy_app'
