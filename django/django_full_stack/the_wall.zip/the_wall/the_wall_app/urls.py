from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('wall/', views.wall),
    path('register/', views.register),
    path('register/process/', views.process),
    path('login/', views.login),
    path('user/', views.user),
    path('logout/', views.logout),
    path('message/', views.post_message),
    path('comment/', views.post_comment),
    path('delete_comment/<int:id>', views.delete_comment)
]
