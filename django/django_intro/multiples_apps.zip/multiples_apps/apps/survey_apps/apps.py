from django.apps import AppConfig


class SurveyAppsConfig(AppConfig):
    name = 'survey_apps'
