from django.apps import AppConfig


class BlogAppsConfig(AppConfig):
    name = 'blog_apps'
