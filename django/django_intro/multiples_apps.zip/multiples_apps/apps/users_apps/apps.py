from django.apps import AppConfig


class UsersAppsConfig(AppConfig):
    name = 'users_apps'
