from django.shortcuts import render, HttpResponse
from time import gmtime, strftime
import datetime

# Create your views here.


def index(request):
    return HttpResponse("Hello World")


def timedisplay(request):
    mydate = datetime.datetime.now()

    context = {
        "time": strftime("%a-%b-%d %H:%M %p", gmtime()),
        "mydate": mydate
    }
    return render(request, 'index.html', context)
