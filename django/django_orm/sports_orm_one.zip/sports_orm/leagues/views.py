from django.shortcuts import render, redirect, HttpResponse
from .models import League, Team, Player

from . import team_maker


def index(request):

    context = {
        "leagues": League.objects.all(),
        "teams": Team.objects.all(),
        "players": Player.objects.all(),
        'women_league': League.objects.filter(name__contains='women'),
        'hockey_league': League.objects.filter(sport__contains='hockey'),
        'not_football_league': League.objects.exclude(sport__contains='football'),
        'conference_leaugue': League.objects.filter(
            name__contains='conference'),
        'atlantic_leagues': League.objects.filter(name__contains='atlantic'),
        'raptors_team': Team.objects.filter(team_name__contains="Raptors"),
        'city_team': Team.objects.filter(location__contains="City"),
        't_team': Team.objects.filter(team_name__startswith="T"),
        'all_location': Team.objects.all().order_by("location"),
        'sorted_team': Team.objects.all().order_by("-team_name"),
        'player_cooper': Player.objects.filter(last_name__contains="cooper"),
        'player_joshua': Player.objects.filter(first_name__contains="joshua"),
        'mix_player': Player.objects.exclude(
            first_name__contains='joshua').filter(last_name__contains='cooper'),
        'alex_wyat': Player.objects.filter(
            first_name__icontains="alexander") or Player.objets.filter(first_name__icontains="wyatt")

    }
    alex_wyat = Player.objects.filter(
        first_name__contains="alexander") or Player.objets.filter(first_name__contains="wyatt")
    for name in alex_wyat:
        print(name.first_name, name.last_name)

    return render(request, "leagues/index.html", context)


def make_data(request):
    team_maker.gen_leagues(10)
    team_maker.gen_teams(50)
    team_maker.gen_players(200)
    return redirect("index")
